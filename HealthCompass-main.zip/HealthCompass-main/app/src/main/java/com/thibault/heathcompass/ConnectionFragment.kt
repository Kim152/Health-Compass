package com.thibault.heathcompass

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.thibault.heathcompass.databinding.FragmentConnectionBinding


class ConnectionFragment : Fragment() {
    private lateinit var binding: FragmentConnectionBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentConnectionBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.registrationButton.setOnClickListener {
            navigateToRegistrationPage()
        }
    }

    private fun navigateToRegistrationPage() {
        requireActivity().supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container_view, RegistrationFragment())
            .addToBackStack("go to the registration page")
            .commit()
    }

    companion object {
        fun newInstance() =
            ConnectionFragment()
    }
}